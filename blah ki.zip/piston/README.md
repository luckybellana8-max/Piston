# PISTON
Android app in /app, AI backend in /server.
1. Backend: cd server && npm i && ANTHROPIC_API_KEY=... npm start (deploy to HTTPS host; put URL in app Settings or BuildConfig).
2. App: open this folder in Android Studio, sync, run on a real device.
Tabs: Piston AI (voice/chat/ideas/essay/code/design, time, weather) | Clipper | Editor | Settings.
