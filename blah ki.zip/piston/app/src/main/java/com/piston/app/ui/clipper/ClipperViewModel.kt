package com.piston.app.ui.clipper
import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.piston.app.clip.*
import com.piston.app.core.Prefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File

class ClipperViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    val source = MutableStateFlow<Uri?>(null)
    val status = MutableStateFlow("Paste a direct video link, or pick a video you own.")
    val busy = MutableStateFlow(false)
    val clips = MutableStateFlow(listClips())
    private var sourceUrl: String? = null
    private fun listClips() = ClipSource.clipDir(getApplication()).listFiles()?.filter { it.extension == "mp4" }?.sortedByDescending { it.lastModified() }.orEmpty()

    fun load(url: String) = viewModelScope.launch {
        busy.value = true
        try { source.value = ClipSource.resolve(getApplication(), url.trim()) { status.value = "Downloading $it%" }; sourceUrl = url.trim(); status.value = "Ready. Watch it, then make clips." }
        catch (e: Exception) { status.value = e.message ?: "Couldn't load that link." }
        busy.value = false
    }
    fun pick(uri: Uri) = viewModelScope.launch { busy.value = true; source.value = ClipSource.copy(getApplication(), uri); sourceUrl = null; status.value = "Ready. Watch it, then make clips."; busy.value = false }

    fun makeClips(count: Int) {
        val src = source.value ?: run { status.value = "Load a video first."; return }
        if (!prefs.consume("export", prefs.plan.exportsPerDay)) { status.value = "Daily export limit reached on the ${prefs.plan.label} plan."; return }
        viewModelScope.launch {
            busy.value = true
            try {
                status.value = "Analyzing the video for best moments…"
                val moments = MomentDetector.detect(getApplication(), src, count.coerceAtMost(prefs.plan.maxClips))
                val height = if (prefs.plan.maxHeight >= 1080) 1920 else 1280
                moments.forEachIndexed { i, m ->
                    status.value = "Exporting clip ${i + 1} of ${moments.size}…"
                    ClipExporter.export(getApplication(), src, m.first, m.last, File(ClipSource.clipDir(getApplication()), "clip_${System.currentTimeMillis()}_$i.mp4"), true, height)
                }
                status.value = "Done. ${moments.size} vertical clips saved."; clips.value = listClips()
            } catch (e: Exception) { status.value = "Failed: ${e.message}" }
            busy.value = false
        }
    }
    fun background(count: Int) {
        if (!prefs.plan.background) { status.value = "Background clipping needs Pro or Ultimate."; return }
        val s = sourceUrl ?: source.value?.path ?: run { status.value = "Load a video first."; return }
        ClipWorker.enqueue(getApplication(), s, count.coerceAtMost(prefs.plan.maxClips))
        status.value = "Queued. Piston will keep working with the app closed and notify you."
    }
    fun refresh() { clips.value = listClips() }
}
