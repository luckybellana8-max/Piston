package com.piston.app.voice
sealed interface Command {
    data class OpenApp(val name: String) : Command
    data class OpenUrl(val url: String) : Command
    data class InstallApp(val name: String) : Command
    data object OpenSettings : Command
    data object Stop : Command
    data class Editor(val action: String) : Command
    data class YouTubeUpload(val latest: Boolean) : Command
    data class Unknown(val text: String) : Command
}
object CommandParser {
    private val wake = Regex("^(hey )?piston[,.]?\\s*", RegexOption.IGNORE_CASE)
    fun parse(raw: String): Command {
        val t = raw.trim().replace(wake, "").lowercase().trimEnd('.', '!')
        return when {
            t in setOf("stop", "cancel", "be quiet") -> Command.Stop
            t == "open settings" -> Command.OpenSettings
            t.startsWith("install ") -> Command.InstallApp(t.removePrefix("install ").trim())
            t.startsWith("open ") -> t.removePrefix("open ").removePrefix("my ").trim().let {
                if (it.contains(".") && !it.contains(" ")) Command.OpenUrl("https://$it") else Command.OpenApp(it) }
            t.contains("upload") && t.contains("youtube") -> Command.YouTubeUpload(t.contains("latest"))
            listOf("edit", "subtitle", "clip", "voice", "silence", "music", "shorts").any { t.contains(it) } -> Command.Editor(t)
            else -> Command.Unknown(raw)
        }
    }
}
