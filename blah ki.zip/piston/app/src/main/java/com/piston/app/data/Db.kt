package com.piston.app.data
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val timelineJson: String = "{}", val updatedAt: Long = System.currentTimeMillis())
@Entity data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromUser: Boolean, val text: String, val ts: Long = System.currentTimeMillis())

@Dao interface ProjectDao {
    @Query("SELECT * FROM ProjectEntity ORDER BY updatedAt DESC") fun projects(): Flow<List<ProjectEntity>>
    @Upsert suspend fun save(p: ProjectEntity): Long
    @Delete suspend fun delete(p: ProjectEntity)
}
@Dao interface ChatDao {
    @Query("SELECT * FROM ChatMessage ORDER BY ts ASC") fun history(): Flow<List<ChatMessage>>
    @Insert suspend fun add(m: ChatMessage)
}
@Database(entities = [ProjectEntity::class, ChatMessage::class], version = 1, exportSchema = false)
abstract class PistonDatabase : RoomDatabase() {
    abstract fun projects(): ProjectDao
    abstract fun chat(): ChatDao
    companion object { fun build(c: Context) = Room.databaseBuilder(c, PistonDatabase::class.java, "piston.db").build() }
}
