package com.piston.app.ui.assistant
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.piston.app.PistonApp
import com.piston.app.core.Plan
import com.piston.app.core.Prefs
import com.piston.app.billing.BillingManager
import com.piston.app.data.ChatMessage
import com.piston.app.net.Backend
import com.piston.app.net.Weather
import com.piston.app.phone.PhoneActions
import com.piston.app.voice.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class AssistantViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    private val chat = (app as PistonApp).db.chat()
    private val phone = PhoneActions(app)
    private val speech = SpeechController(app, prefs) { submit(it, "chat", fromVoice = true) }
    val level = speech.level; val listening = speech.listening; val error = speech.error
    val history = chat.history().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    private val _busy = MutableStateFlow(false); val busy: StateFlow<Boolean> = _busy
    private val _weather = MutableStateFlow<String?>(null); val weather: StateFlow<String?> = _weather

    private val _plan = MutableStateFlow(prefs.plan); val plan: StateFlow<Plan> = _plan
    val billing = BillingManager(app, prefs) { _plan.value = prefs.plan }
    fun setPlanDebug(p: Plan) { prefs.plan = p; _plan.value = p }
    init { refreshWeather(); billing.connect() }
    fun refreshWeather() { if (prefs.city.isNotBlank()) viewModelScope.launch { _weather.value = Weather.summary(prefs.city) } }
    fun now(): String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy, HH:mm"))

    fun toggleListening() = if (listening.value) speech.stopListening() else speech.listen()
    fun voices() = speech.voices()
    fun previewVoice(name: String) { speech.setVoice(name); speech.speak("Hello ${prefs.address}, I am Piston.") }
    fun useVoice(name: String) { prefs.voiceName = name; speech.setVoice(name) }
    fun setPitch(p: Float) { prefs.pitch = p; speech.setPitch(p) }

    private fun reply(text: String, speak: Boolean = true) {
        if (speak) speech.speak(text)
        viewModelScope.launch { chat.add(ChatMessage(fromUser = false, text = text)) }
    }

    fun submit(raw: String, mode: String, fromVoice: Boolean = false) {
        if (raw.isBlank()) return
        viewModelScope.launch { chat.add(ChatMessage(fromUser = true, text = raw)) }
        val cmd = if (mode == "chat") CommandParser.parse(raw) else Command.Unknown(raw)
        val addr = prefs.address.ifBlank { "" }.let { if (it.isBlank()) "" else ", $it" }
        when (cmd) {
            Command.Stop -> speech.stopSpeaking()
            Command.OpenSettings -> { phone.openSettings(); reply("Opening settings$addr.") }
            is Command.OpenUrl -> { phone.openUrl(cmd.url); reply("Opening ${cmd.url}.") }
            is Command.OpenApp -> reply(if (phone.openApp(cmd.name)) "Opening ${cmd.name}." else "I couldn't find ${cmd.name} on this phone$addr.")
            is Command.InstallApp -> { phone.installViaPlayStore(cmd.name); reply("Opening the Play Store. Tap Install to approve.") }
            is Command.Editor -> reply("Open the Clipper or Editor tab to do that$addr. Voice-driven editing is the next step.")
            is Command.YouTubeUpload -> reply("YouTube upload isn't connected yet. When it is, I will always ask before publishing.")
            is Command.Unknown -> ask(raw, mode, fromVoice)
        }
    }

    private fun ask(text: String, mode: String, fromVoice: Boolean) {
        if (!prefs.consume("ai", prefs.plan.aiPerDay)) { reply("You've reached the daily AI limit on the ${prefs.plan.label} plan.", false); return }
        viewModelScope.launch {
            _busy.value = true
            val ctx = "Current local time: ${now()}." + (_weather.value?.let { " Weather: $it." } ?: "")
            val msgs = history.value.takeLast(12).map { (if (it.fromUser) "user" else "assistant") to it.text }
                .let { if (it.lastOrNull()?.second != text) it + ("user" to text) else it }
            val out = runCatching { Backend.chat(prefs.backendUrl, mode, msgs, ctx, prefs.address) }
            reply(out.getOrElse { "I couldn't reach the AI backend (${it.message}). Check the backend URL in Settings." }, speak = fromVoice && out.isSuccess)
            _busy.value = false
        }
    }
    override fun onCleared() { speech.release(); billing.close() }
}
