package com.piston.app
import android.app.Application
import com.piston.app.data.PistonDatabase
class PistonApp : Application() {
    val db by lazy { PistonDatabase.build(this) }
}
