package com.piston.app.ui.editor
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.piston.app.clip.ClipExporter
import com.piston.app.clip.ClipSource
import com.piston.app.core.Prefs
import com.piston.app.ui.VideoPlayer
import com.piston.app.ui.theme.Black
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope(); val prefs = remember { Prefs(ctx) }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var dur by remember { mutableFloatStateOf(1f) }
    var range by remember { mutableStateOf(0f..1f) }
    var vertical by remember { mutableStateOf(false) }
    var height by remember { mutableIntStateOf(720) }
    var status by remember { mutableStateOf("Pick a video to start.") }
    var busy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) scope.launch {
            val f = ClipSource.copy(ctx, u); uri = f
            dur = ClipExporter.durationMs(ctx, f).toFloat().coerceAtLeast(1f); range = 0f..dur; status = "Loaded."
        }
    }
    Column(Modifier.fillMaxSize().background(Black).statusBarsPadding().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("PISTON EDITOR", color = Color.White, style = MaterialTheme.typography.titleLarge)
        Button({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }) { Text("Pick video") }
        if (uri != null) {
            VideoPlayer(uri, Modifier.fillMaxWidth().height(220.dp))
            Text("Trim: ${(range.start / 1000).toInt()}s – ${(range.endInclusive / 1000).toInt()}s of ${(dur / 1000).toInt()}s", color = Color.White)
            RangeSlider(range, { range = it }, valueRange = 0f..dur)
            Row { Checkbox(vertical, { vertical = it }); Text("Vertical 9:16 (Shorts)", color = Color.White, modifier = Modifier.padding(top = 12.dp)) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(720, 1080, 2160).forEach { h ->
                    FilterChip(height == h, { height = h }, label = { Text(if (h == 2160) "4K" else "${h}p") }, enabled = h <= prefs.plan.maxHeight)
                }
            }
            Button(enabled = !busy, onClick = {
                if (!prefs.consume("export", prefs.plan.exportsPerDay)) { status = "Daily export limit reached on the ${prefs.plan.label} plan."; return@Button }
                scope.launch {
                    busy = true; status = "Exporting…"
                    val out = File(ClipSource.clipDir(ctx), "edit_${System.currentTimeMillis()}.mp4")
                    status = runCatching {
                        ClipExporter.export(ctx, uri!!, range.start.toLong(), range.endInclusive.toLong(), out, vertical, if (vertical) height * 16 / 9 else height)
                        "Saved: ${out.name} (Movies/PistonClips)"
                    }.getOrElse { "Export failed: ${it.message}" }
                    busy = false
                }
            }) { Text("Export") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(status, color = Color.LightGray)
        Text("Coming next: multi-track timeline, text, subtitles, music, filters.", color = Color.Gray)
    }
}
