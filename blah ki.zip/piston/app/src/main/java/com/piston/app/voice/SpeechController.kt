package com.piston.app.voice
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import com.piston.app.core.Prefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

class SpeechController(private val ctx: Context, private val prefs: Prefs, private val onResult: (String) -> Unit) {
    private val _level = MutableStateFlow(0f); val level: StateFlow<Float> = _level
    private val _listening = MutableStateFlow(false); val listening: StateFlow<Boolean> = _listening
    private val _error = MutableStateFlow<String?>(null); val error: StateFlow<String?> = _error
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = TextToSpeech(ctx) { if (it == TextToSpeech.SUCCESS) { tts?.language = Locale.getDefault(); setVoice(prefs.voiceName); setPitch(prefs.pitch) } }

    fun voices(): List<Voice> = tts?.voices.orEmpty().filter { it.locale.language == Locale.getDefault().language && !it.isNetworkConnectionRequired }.sortedBy { it.name }
    fun setVoice(name: String?) { name ?: return; tts?.voices?.firstOrNull { it.name == name }?.let { tts?.voice = it } }
    fun setPitch(p: Float) { tts?.setPitch(p) }

    fun listen(locale: Locale = Locale.getDefault()) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { _error.value = "Speech recognition unavailable on this device"; return }
        stopSpeaking(); recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { _listening.value = true; _error.value = null }
                override fun onRmsChanged(rms: Float) { _level.value = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onResults(r: Bundle?) { _listening.value = false; _level.value = 0f
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onResult) }
                override fun onError(code: Int) { _listening.value = false; _level.value = 0f; _error.value = "Speech error $code" }
                override fun onBeginningOfSpeech() {}; override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toLanguageTag()) })
        }
    }
    fun stopListening() { recognizer?.stopListening(); _listening.value = false }
    fun speak(text: String) { tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "piston") }
    fun stopSpeaking() { tts?.stop() }
    fun release() { recognizer?.destroy(); tts?.shutdown() }
}
