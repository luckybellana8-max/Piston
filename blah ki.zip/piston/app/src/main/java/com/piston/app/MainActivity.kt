package com.piston.app
import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.piston.app.ui.assistant.AIScreen
import com.piston.app.ui.clipper.ClipperScreen
import com.piston.app.ui.editor.EditorScreen
import com.piston.app.ui.settings.SettingsScreen
import com.piston.app.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            PistonTheme {
                val tabs = listOf("Piston AI", "Clipper", "Editor", "Settings")
                var tab by remember { mutableIntStateOf(0) }
                Scaffold(containerColor = Black, bottomBar = {
                    NavigationBar(containerColor = Surface) {
                        tabs.forEachIndexed { i, t -> NavigationBarItem(tab == i, { tab = i }, icon = { Text(if (tab == i) "●" else "○") }, label = { Text(t) }) }
                    }
                }) { pad ->
                    androidx.compose.foundation.layout.Box(Modifier.padding(pad)) {
                        when (tab) { 0 -> AIScreen(); 1 -> ClipperScreen(); 2 -> EditorScreen(); else -> SettingsScreen() }
                    }
                }
            }
        }
    }
}
