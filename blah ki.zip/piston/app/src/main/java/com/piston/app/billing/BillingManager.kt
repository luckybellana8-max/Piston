package com.piston.app.billing
import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*
import com.piston.app.BuildConfig
import com.piston.app.core.Plan
import com.piston.app.core.Prefs
import kotlinx.coroutines.flow.MutableStateFlow

/** Google Play Billing for the Pro and Ultimate subscriptions. Product ids must match Play Console. */
class BillingManager(ctx: Context, private val prefs: Prefs, private val onChange: () -> Unit) : PurchasesUpdatedListener {
    val prices = MutableStateFlow<Map<String, String>>(emptyMap())
    private var details = mapOf<String, ProductDetails>()
    private val client = BillingClient.newBuilder(ctx).setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()).build()

    fun connect() {
        if (client.isReady) return
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(r: BillingResult) { if (r.responseCode == BillingClient.BillingResponseCode.OK) { loadProducts(); restore() } }
            override fun onBillingServiceDisconnected() {}
        })
    }
    private fun loadProducts() {
        val list = Plan.values().mapNotNull { it.productId }.map {
            QueryProductDetailsParams.Product.newBuilder().setProductId(it).setProductType(BillingClient.ProductType.SUBS).build() }
        client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(list).build()) { _, found ->
            details = found.associateBy { it.productId }
            prices.value = found.associate { d -> d.productId to ((d.subscriptionOfferDetails?.firstOrNull()?.pricingPhases?.pricingPhaseList?.firstOrNull()?.formattedPrice)?.let { "$it / month" } ?: "") }
        }
    }
    fun buy(activity: Activity, plan: Plan) {
        val d = details[plan.productId] ?: return
        val token = d.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: return
        val p = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).setOfferToken(token).build()
        client.launchBillingFlow(activity, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(p)).build())
    }
    fun restore() {
        if (!client.isReady) { connect(); return }
        client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()) { r, list ->
            if (r.responseCode != BillingClient.BillingResponseCode.OK) return@queryPurchasesAsync
            apply(list)
            if (list.none { it.purchaseState == Purchase.PurchaseState.PURCHASED } && !BuildConfig.DEBUG) { prefs.plan = Plan.FREE; onChange() }
        }
    }
    override fun onPurchasesUpdated(r: BillingResult, list: MutableList<Purchase>?) {
        if (r.responseCode == BillingClient.BillingResponseCode.OK && list != null) apply(list)
    }
    private fun apply(list: List<Purchase>) {
        val owned = list.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED }
        owned.filter { !it.isAcknowledged }.forEach {
            client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(it.purchaseToken).build()) {} }
        val ids = owned.flatMap { it.products }
        val best = Plan.values().filter { it.productId != null && it.productId in ids }.maxByOrNull { it.ordinal }
        if (best != null) { prefs.plan = best; onChange() }
    }
    fun close() { client.endConnection() }
}
