@file:OptIn(UnstableApi::class)
package com.piston.app.clip
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Crop
import androidx.media3.effect.Presentation
import androidx.media3.transformer.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Real export using Media3 Transformer: trim + optional 9:16 center-crop + scale to a target height. */
object ClipExporter {
    private fun meta(ctx: Context, uri: Uri, key: Int): String? =
        MediaMetadataRetriever().run { try { setDataSource(ctx, uri); extractMetadata(key) } finally { release() } }

    fun durationMs(ctx: Context, uri: Uri): Long = meta(ctx, uri, MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L

    private fun dims(ctx: Context, uri: Uri): Pair<Int, Int> {
        var w = meta(ctx, uri, MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
        var h = meta(ctx, uri, MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
        val rot = meta(ctx, uri, MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        return w to h
    }

    suspend fun export(ctx: Context, src: Uri, startMs: Long, endMs: Long, out: File, vertical: Boolean, height: Int): File =
        withContext(Dispatchers.Main) {
            val (w, h) = dims(ctx, src)
            val fx = mutableListOf<Effect>()
            if (vertical) {
                val f = ((9f / 16f) / (w.toFloat() / h)).coerceAtMost(1f)
                if (f < 1f) fx += Crop(-f, f, -1f, 1f)
            }
            fx += Presentation.createForHeight(height)
            val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs).setEndPositionMs(endMs).build()
            val item = EditedMediaItem.Builder(MediaItem.Builder().setUri(src).setClippingConfiguration(clip).build())
                .setEffects(Effects(emptyList(), fx)).build()
            suspendCancellableCoroutine { cont ->
                val t = Transformer.Builder(ctx).addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) { cont.resume(out) }
                    override fun onError(composition: Composition, exportResult: ExportResult, e: ExportException) { cont.resumeWithException(e) }
                }).build()
                cont.invokeOnCancellation { t.cancel() }
                t.start(item, out.absolutePath)
            }
        }
}
