package com.piston.app.clip
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.piston.app.core.Prefs
import java.io.File

/** Runs clip generation even when the app is closed (foreground-service-backed WorkManager job). */
class ClipWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    private fun note(text: String, ongoing: Boolean) {
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("clips", "Piston Clips", NotificationManager.IMPORTANCE_LOW))
        nm.notify(if (ongoing) 1 else 2, build(text, ongoing))
    }
    private fun build(text: String, ongoing: Boolean) = NotificationCompat.Builder(applicationContext, "clips")
        .setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("PISTON Clips").setContentText(text).setOngoing(ongoing).build()

    override suspend fun doWork(): Result {
        val src = inputData.getString("src") ?: return Result.failure()
        val count = inputData.getInt("count", 5)
        applicationContext.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("clips", "Piston Clips", NotificationManager.IMPORTANCE_LOW))
        val n = build("Working on your clips…", true)
        setForeground(if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else ForegroundInfo(1, n))
        return try {
            val uri = if (src.startsWith("http")) ClipSource.resolve(applicationContext, src) {} else Uri.fromFile(File(src))
            val height = if (Prefs(applicationContext).plan.maxHeight >= 1080) 1920 else 1280
            val moments = MomentDetector.detect(applicationContext, uri, count)
            val dir = ClipSource.clipDir(applicationContext)
            moments.forEachIndexed { i, m ->
                note("Exporting clip ${i + 1} of ${moments.size}", true)
                ClipExporter.export(applicationContext, uri, m.first, m.last, File(dir, "clip_${System.currentTimeMillis()}_$i.mp4"), true, height)
            }
            note("${moments.size} clips are ready in Piston Clips.", false); Result.success()
        } catch (e: Exception) { note("Clip job failed: ${e.message}", false); Result.failure() }
    }
    companion object {
        fun enqueue(ctx: Context, src: String, count: Int) = WorkManager.getInstance(ctx).enqueue(
            OneTimeWorkRequestBuilder<ClipWorker>().setInputData(workDataOf("src" to src, "count" to count))
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())
    }
}
