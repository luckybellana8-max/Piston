package com.piston.app.net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object Net {
    val http: OkHttpClient = OkHttpClient.Builder().readTimeout(90, TimeUnit.SECONDS).build()
    fun get(url: String): String = http.newCall(Request.Builder().url(url).build()).execute().use {
        if (!it.isSuccessful) error("HTTP ${it.code}"); it.body?.string().orEmpty() }
}

object Backend {
    suspend fun chat(base: String, mode: String, msgs: List<Pair<String, String>>, context: String, address: String): String =
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("mode", mode).put("context", context).put("address", address)
                .put("messages", JSONArray(msgs.map { JSONObject().put("role", it.first).put("content", it.second) }))
            val req = Request.Builder().url("$base/chat").post(body.toString().toRequestBody("application/json".toMediaType())).build()
            Net.http.newCall(req).execute().use { r ->
                val t = r.body?.string().orEmpty()
                if (!r.isSuccessful) error("Backend returned HTTP ${r.code}")
                JSONObject(t).getString("reply")
            }
        }
}

/** Open-Meteo: free, no API key. */
object Weather {
    private fun describe(c: Int) = when (c) {
        0 -> "clear"; 1, 2, 3 -> "partly cloudy"; 45, 48 -> "foggy"
        in 51..67 -> "rainy"; in 71..77 -> "snowy"; in 80..82 -> "showery"; in 95..99 -> "stormy"; else -> "unsettled" }
    suspend fun summary(city: String): String? = withContext(Dispatchers.IO) {
        try {
            val g = JSONObject(Net.get("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + URLEncoder.encode(city, "UTF-8")))
            val r = g.optJSONArray("results")?.getJSONObject(0) ?: return@withContext null
            val w = JSONObject(Net.get("https://api.open-meteo.com/v1/forecast?latitude=${r.getDouble("latitude")}&longitude=${r.getDouble("longitude")}&current=temperature_2m,weather_code,wind_speed_10m")).getJSONObject("current")
            "${r.getString("name")}: ${w.getDouble("temperature_2m")}°C, ${describe(w.getInt("weather_code"))}, wind ${w.getDouble("wind_speed_10m")} km/h"
        } catch (e: Exception) { null }
    }
}
