package com.piston.app.ui.settings
import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.piston.app.BuildConfig
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.piston.app.core.Plan
import com.piston.app.ui.assistant.AssistantViewModel
import com.piston.app.ui.theme.Black

@Composable
fun SettingsScreen(vm: AssistantViewModel = viewModel()) {
    val p = vm.prefs
    val plan by vm.plan.collectAsStateWithLifecycle()
    val prices by vm.billing.prices.collectAsStateWithLifecycle()
    val act = LocalContext.current as Activity
    var address by remember { mutableStateOf(p.address) }
    var city by remember { mutableStateOf(p.city) }
    var backend by remember { mutableStateOf(p.backendUrl) }
    var pitch by remember { mutableFloatStateOf(p.pitch) }
    var voices by remember { mutableStateOf(vm.voices()) }
    var selected by remember { mutableStateOf(p.voiceName) }

    Column(Modifier.fillMaxSize().background(Black).statusBarsPadding().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", color = Color.White, style = MaterialTheme.typography.titleLarge)
        Text("Your plan: ${plan.label}", color = Color.White, style = MaterialTheme.typography.titleMedium)
        Plan.values().forEach { pl ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(pl.label + (pl.productId?.let { prices[it] }?.let { "  ·  $it" } ?: ""), style = MaterialTheme.typography.titleSmall)
                    pl.perks.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    if (pl != Plan.FREE && plan != pl) Button({ vm.billing.buy(act, pl) }) { Text("Upgrade to ${pl.label}") }
                    if (plan == pl) Text("Current plan", color = Color(0xFF8B2BFF))
                }
            }
        }
        TextButton({ vm.billing.restore() }) { Text("Restore purchases") }
        if (BuildConfig.DEBUG) {
            Text("Debug only: switch plan for testing", color = Color.Gray)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Plan.values().forEach { pl -> FilterChip(selected = plan == pl, onClick = { vm.setPlanDebug(pl) }, label = { Text(pl.label) }) } }
        }
        Text("Address me as", color = Color.White)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("sir", "ma'am", "").forEach { a -> FilterChip(address == a, { address = a; p.address = a }, label = { Text(a.ifBlank { "by name only" }) }) }
        }
        OutlinedTextField(city, { city = it; p.city = it }, Modifier.fillMaxWidth(), label = { Text("City (for weather)") }, singleLine = true)
        TextButton({ vm.refreshWeather() }) { Text("Update weather") }
        OutlinedTextField(backend, { backend = it; p.backendUrl = it }, Modifier.fillMaxWidth(), label = { Text("AI backend URL") }, singleLine = true)
        Text("Voice (pitch ${"%.2f".format(pitch)}; lower = deeper)", color = Color.White)
        Slider(pitch, { pitch = it; vm.setPitch(it) }, valueRange = 0.6f..1.4f)
        TextButton({ voices = vm.voices() }) { Text("Refresh voices") }
        voices.take(12).forEach { v ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text((if (selected == v.name) "✓ " else "") + v.name, color = Color.LightGray, modifier = Modifier.weight(1f))
                TextButton({ vm.previewVoice(v.name) }) { Text("Preview") }
                TextButton({ vm.useVoice(v.name); selected = v.name }) { Text("Use") }
            }
        }
        if (voices.isEmpty()) Text("No offline voices found. Install more in system Text-to-speech settings.", color = Color.Gray)
    }
}
