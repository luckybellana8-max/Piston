package com.piston.app.ui.assistant
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.piston.app.ui.theme.*
import kotlin.math.abs
import kotlin.math.sin

private val modes = listOf("chat" to "Chat", "ideas" to "Ideas", "essay" to "Essay", "code" to "Code", "design" to "Design")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AIScreen(vm: AssistantViewModel = viewModel()) {
    val listening by vm.listening.collectAsStateWithLifecycle()
    val level by vm.level.collectAsStateWithLifecycle()
    val err by vm.error.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val weather by vm.weather.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    var mode by remember { mutableStateOf("chat") }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) vm.toggleListening() }
    LaunchedEffect(history.size) { if (history.isNotEmpty()) listState.animateScrollToItem(history.size - 1) }

    Column(Modifier.fillMaxSize().background(Black).statusBarsPadding().padding(horizontal = 16.dp)) {
        Text("PISTON", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Text(vm.now() + (weather?.let { "  ·  $it" } ?: ""), color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            modes.forEach { (k, label) -> FilterChip(selected = mode == k, onClick = { mode = k }, label = { Text(label) }) }
        }
        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(history) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.text, color = Color.White, modifier = Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(14.dp))
                        .background(if (m.fromUser) Purple.copy(alpha = 0.6f) else Surface).padding(12.dp))
                }
            }
            if (busy) item { Text("Thinking…", color = Color.Gray) }
        }
        err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp) }
        Waveform(level, listening)
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Ask Piston…") }, maxLines = 4)
            Spacer(Modifier.width(8.dp))
            Orb(listening, level) { perm.launch(Manifest.permission.RECORD_AUDIO) }
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.submit(input, mode); input = "" }, enabled = input.isNotBlank() && !busy) { Text("Send") }
        }
    }
}

@Composable
private fun Orb(active: Boolean, level: Float, onClick: () -> Unit) {
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(1f, 1.15f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "s")
    val s = if (active) pulse + level * 0.2f else 1f
    Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size((46 * s).dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue))).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            Text(if (active) "■" else "●", color = Color.White)
        }
    }
}

@Composable
private fun Waveform(level: Float, active: Boolean) {
    val t by rememberInfiniteTransition(label = "w").animateFloat(0f, 6.28f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "t")
    Canvas(Modifier.fillMaxWidth().height(32.dp)) {
        val n = 32; val w = size.width / (n * 1.6f)
        for (i in 0 until n) {
            val amp = if (active) (0.15f + level * abs(sin(t + i * 0.5f))) else 0.05f
            val h = size.height * amp.coerceAtMost(1f)
            drawRect(Brush.verticalGradient(listOf(Purple, Blue)), Offset(i * w * 1.6f + w * 0.3f, (size.height - h) / 2), Size(w, h))
        }
    }
}
