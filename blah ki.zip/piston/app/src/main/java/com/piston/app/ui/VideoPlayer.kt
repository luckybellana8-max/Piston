@file:OptIn(UnstableApi::class)
package com.piston.app.ui
import android.net.Uri
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

@Composable
fun VideoPlayer(uri: Uri?, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(uri) { if (uri != null) { player.setMediaItem(MediaItem.fromUri(uri)); player.prepare() } }
    AndroidView({ PlayerView(it).apply { this.player = player } }, modifier)
}
