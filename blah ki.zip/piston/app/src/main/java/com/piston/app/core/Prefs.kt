package com.piston.app.core
import android.content.Context
import com.piston.app.BuildConfig

enum class Plan(val label: String, val productId: String?, val aiPerDay: Int, val exportsPerDay: Int, val maxHeight: Int, val maxClips: Int, val background: Boolean, val perks: List<String>) {
    FREE("Free", null, 15, 3, 720, 3, false, listOf("15 AI messages per day", "3 exports per day", "720p export", "3 clips per run")),
    PRO("Pro", "piston_pro", 150, 25, 1080, 10, true, listOf("150 AI messages per day", "25 exports per day", "1080p export", "10 clips per run", "Background clipping")),
    ULTIMATE("Ultimate", "piston_ultimate", Int.MAX_VALUE, Int.MAX_VALUE, 2160, 25, true, listOf("Unlimited AI messages", "Unlimited exports", "4K export", "25 clips per run", "Background clipping", "First access to new features (YouTube analytics, faceless videos)"))
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("piston", Context.MODE_PRIVATE)
    var plan: Plan
        get() = runCatching { Plan.valueOf(sp.getString("plan", "FREE")!!) }.getOrDefault(Plan.FREE)
        set(v) = sp.edit().putString("plan", v.name).apply()
    var voiceName: String? get() = sp.getString("voice", null); set(v) = sp.edit().putString("voice", v).apply()
    var pitch: Float get() = sp.getFloat("pitch", 1f); set(v) = sp.edit().putFloat("pitch", v).apply()
    var address: String get() = sp.getString("address", "sir")!!; set(v) = sp.edit().putString("address", v).apply()
    var city: String get() = sp.getString("city", "")!!; set(v) = sp.edit().putString("city", v).apply()
    var backendUrl: String get() = sp.getString("backend", BuildConfig.BACKEND_URL)!!; set(v) = sp.edit().putString("backend", v.trimEnd('/')).apply()

    /** Daily quota counter. Returns false when the limit is reached. */
    fun consume(key: String, limit: Int): Boolean {
        val k = "$key:${java.time.LocalDate.now()}"
        val n = sp.getInt(k, 0)
        if (n >= limit) return false
        sp.edit().putInt(k, n + 1).apply(); return true
    }
}
