package com.piston.app.clip
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.abs

/** On-device "best moments": finds the loudest/most energetic spots in the audio (laughs, shouting, hype). */
object MomentDetector {
    suspend fun detect(ctx: Context, uri: Uri, count: Int, clipSec: Int = 30): List<LongRange> = withContext(Dispatchers.Default) {
        val ex = MediaExtractor(); ex.setDataSource(ctx, uri, null)
        val track = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
        val durSec: Int
        val energy: DoubleArray
        if (track == null) { ex.release(); val d = (ClipExporter.durationMs(ctx, uri) / 1000).toInt(); return@withContext evenly(d, count, clipSec) }
        val fmt = ex.getTrackFormat(track); ex.selectTrack(track)
        durSec = (fmt.getLong(MediaFormat.KEY_DURATION) / 1_000_000).toInt() + 1
        energy = DoubleArray(durSec + 2)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0); codec.start()
        val info = MediaCodec.BufferInfo(); var inDone = false; var outDone = false
        while (!outDone) {
            if (!inDone) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val n = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                    if (n < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            if (o >= 0) {
                if (info.size > 0) {
                    val ob = codec.getOutputBuffer(o)!!; ob.position(info.offset); ob.limit(info.offset + info.size)
                    val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val sec = (info.presentationTimeUs / 1_000_000).toInt().coerceIn(0, energy.size - 1)
                    var sum = 0.0; while (sb.hasRemaining()) sum += abs(sb.get().toInt())
                    energy[sec] += sum
                }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            }
        }
        codec.stop(); codec.release(); ex.release()
        // smooth over a 5s window, then pick the highest peaks that don't overlap
        val smooth = DoubleArray(durSec) { s -> (maxOf(0, s - 2)..minOf(durSec - 1, s + 2)).sumOf { energy[it] } }
        val picked = mutableListOf<Int>()
        for (s in smooth.indices.sortedByDescending { smooth[it] }) {
            if (picked.size >= count) break
            if (picked.none { abs(it - s) < clipSec }) picked += s
        }
        picked.sorted().map { peak ->
            val start = (peak - (clipSec * 0.4).toInt()).coerceAtLeast(0)
            val end = minOf(durSec, start + clipSec)
            (start * 1000L)..(end * 1000L)
        }
    }
    private fun evenly(durSec: Int, count: Int, clipSec: Int) =
        (0 until count).map { i -> val s = (durSec.toLong() * i / count); (s * 1000)..(minOf(durSec.toLong(), s + clipSec) * 1000) }
}
