package com.piston.app.ui.clipper
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.piston.app.ui.VideoPlayer
import com.piston.app.core.Prefs
import androidx.compose.ui.platform.LocalContext
import com.piston.app.ui.theme.Black

@Composable
fun ClipperScreen(vm: ClipperViewModel = viewModel()) {
    val source by vm.source.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val clips by vm.clips.collectAsStateWithLifecycle()
    var url by remember { mutableStateOf("") }
    var count by remember { mutableFloatStateOf(5f) }
    var playing by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { it?.let(vm::pick) }

    Column(Modifier.fillMaxSize().background(Black).statusBarsPadding().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("PISTON CLIPS", color = Color.White, style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("Direct video link (https://…mp4)") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.load(url) }, enabled = url.isNotBlank() && !busy) { Text("Load link") }
            OutlinedButton({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, enabled = !busy) { Text("Pick my video") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(status, color = Color.LightGray)
        if (source != null) {
            VideoPlayer(playing ?: source, Modifier.fillMaxWidth().height(220.dp))
            Text("Clips to make: ${count.toInt()}", color = Color.White)
            Slider(count, { count = it }, valueRange = 1f..Prefs(LocalContext.current).plan.maxClips.toFloat().coerceAtLeast(2f))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ vm.makeClips(count.toInt()) }, enabled = !busy) { Text("Make best-moment clips") }
                OutlinedButton({ vm.background(count.toInt()) }, enabled = !busy) { Text("Run in background") }
            }
        }
        if (clips.isNotEmpty()) {
            Text("Saved clips (9:16)", color = Color.White, style = MaterialTheme.typography.titleMedium)
            clips.forEach { f -> OutlinedButton({ playing = Uri.fromFile(f) }, Modifier.fillMaxWidth()) { Text(f.name) } }
            TextButton({ vm.refresh() }) { Text("Refresh list") }
        }
    }
}
