package com.piston.app.clip
import android.content.Context
import android.net.Uri
import com.piston.app.net.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File

object ClipSource {
    private val direct = Regex(".*\\.(mp4|mov|m4v|webm|mkv)(\\?.*)?$", RegexOption.IGNORE_CASE)
    private val blocked = listOf("youtube.com", "youtu.be", "tiktok.com", "instagram.com", "twitch.tv", "facebook.com", "vimeo.com", "x.com", "twitter.com")

    fun clipDir(ctx: Context) = File(ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), "PistonClips").apply { mkdirs() }

    fun validate(url: String) {
        val host = Uri.parse(url).host ?: error("That isn't a valid link.")
        if (blocked.any { host == it || host.endsWith(".$it") })
            error("$host doesn't allow downloads. Use a direct video file link, or pick a video you own from your phone.")
        if (!url.startsWith("https://") || !direct.matches(url)) error("Use a direct https link to a video file (.mp4, .mov, .webm).")
    }

    suspend fun resolve(ctx: Context, url: String, onProgress: (Int) -> Unit): Uri = withContext(Dispatchers.IO) {
        validate(url)
        val out = File(ctx.cacheDir, "src_${url.hashCode()}.mp4")
        if (!out.exists() || out.length() == 0L) {
            Net.http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) error("Download failed: HTTP ${r.code}")
                val body = r.body ?: error("Empty response")
                val total = body.contentLength(); var read = 0L
                body.byteStream().use { i -> out.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); read += n; if (total > 0) onProgress((read * 100 / total).toInt()) }
                } }
            }
        }
        Uri.fromFile(out)
    }

    /** Copies a picked content:// video into app storage so background work keeps access. */
    suspend fun copy(ctx: Context, uri: Uri): Uri = withContext(Dispatchers.IO) {
        val out = File(ctx.cacheDir, "pick_${System.currentTimeMillis()}.mp4")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { i.copyTo(it) } }
        Uri.fromFile(out)
    }
}
