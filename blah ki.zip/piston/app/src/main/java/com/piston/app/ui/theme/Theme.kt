package com.piston.app.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
val Black = Color(0xFF000000); val Surface = Color(0xFF0D0D14)
val Purple = Color(0xFF8B2BFF); val Blue = Color(0xFF2B7BFF)
@Composable fun PistonTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Purple, secondary = Blue, background = Black, surface = Surface),
    content = content)
