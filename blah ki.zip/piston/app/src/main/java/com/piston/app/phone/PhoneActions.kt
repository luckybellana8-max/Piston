package com.piston.app.phone
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/** Public Android APIs only. Never installs silently: Play Store opens and the user approves. */
class PhoneActions(private val ctx: Context) {
    private fun launch(i: Intent): Boolean = try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }

    fun openApp(spokenName: String): Boolean {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().contains(spokenName, ignoreCase = true) }
        return match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName)?.let(::launch) } ?: false
    }
    fun openUrl(url: String) = launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    fun openSettings() = launch(Intent(Settings.ACTION_SETTINGS))
    fun installViaPlayStore(name: String) {
        val known = mapOf("capcut" to "com.lemon.lvoverseas")
        val pkg = known[name.lowercase()]
        val uri = if (pkg != null) Uri.parse("market://details?id=$pkg") else Uri.parse("market://search?q=${Uri.encode(name)}&c=apps")
        if (!launch(Intent(Intent.ACTION_VIEW, uri))) openUrl("https://play.google.com/store/search?q=${Uri.encode(name)}&c=apps")
    }
}
