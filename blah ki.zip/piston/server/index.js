// PISTON backend: keeps the AI key off the phone. Run: ANTHROPIC_API_KEY=sk-... npm start
import express from "express";
const app = express();
app.use(express.json({ limit: "1mb" }));

const SYSTEM = {
  chat: "You are PISTON, a capable voice assistant with broad world knowledge. Be concise. If unsure, say so.",
  ideas: "You are PISTON's idea engine. Give 5-8 specific, original ideas (video, channel, business, content), each with a one-line hook.",
  essay: "You are PISTON's essay helper. Write a clear, well-structured essay with intro, body, conclusion. Offer to adjust tone/length. Write original text.",
  code: "You are PISTON's coding assistant. Give working, commented code in fenced blocks and a short explanation.",
  design: "You are PISTON's design assistant. Give concrete UI/brand/thumbnail design direction: palette (hex), type, layout, and why.",
};

app.post("/chat", async (req, res) => {
  try {
    const { mode = "chat", messages = [], context = "", address = "" } = req.body;
    let msgs = messages.slice(-20).map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content).slice(0, 8000) }));
    while (msgs.length && msgs[0].role !== "user") msgs.shift();
    if (!msgs.length) return res.status(400).json({ error: "no messages" });
    const system = `${SYSTEM[mode] || SYSTEM.chat}\n${context}\n` + (address ? `Address the user as "${address}" naturally, not in every sentence.` : "");
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: process.env.MODEL || "claude-sonnet-5-5", max_tokens: mode === "essay" ? 3000 : 1500, system, messages: msgs }),
    });
    const j = await r.json();
    if (!r.ok) return res.status(502).json({ error: j });
    res.json({ reply: j.content.filter(b => b.type === "text").map(b => b.text).join("\n") });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});
app.listen(process.env.PORT || 8787, () => console.log("PISTON backend up"));
